"""Пример: как запускать бота вместе с вашим FastAPI-приложением.
Скопируйте lifespan в ваш app/main.py (или объедините с уже существующим)."""
import asyncio
from contextlib import asynccontextmanager, suppress

from fastapi import FastAPI

from bot.main import run_bot


@asynccontextmanager
async def lifespan(app: FastAPI):
    task = asyncio.create_task(run_bot(standalone=False))
    yield
    task.cancel()
    with suppress(asyncio.CancelledError):
        await task


app = FastAPI(lifespan=lifespan)  # ваши роуты остаются как есть
