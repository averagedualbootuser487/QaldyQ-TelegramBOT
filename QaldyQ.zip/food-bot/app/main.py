"""Тестовый API для бота (данные хранятся в памяти и пропадают при перезапуске).
Запуск вместе с ботом:  python -m uvicorn app.main:app
"""
import asyncio
import logging
import os
from contextlib import asynccontextmanager, suppress

from fastapi import FastAPI, HTTPException, Query
from pydantic import BaseModel, Field

from bot.main import run_bot

COMMISSION = 0.20


class OfferIn(BaseModel):
    cafe_name: str
    title: str
    description: str = ""
    old_price: float = Field(gt=0)
    new_price: float = Field(gt=0)
    quantity: int = Field(gt=0)
    pickup_time: str = ""
    city: str


class OrderIn(BaseModel):
    offer_id: int
    quantity: int = Field(gt=0)
    customer_name: str
    phone: str
    telegram_user_id: int | None = None


OFFERS: dict[int, dict] = {}
ORDERS: list[dict] = []


DEMO_OFFERS = [
    ("Кофейня «Сахар»", "Набор выпечки", "3 круассана и 2 булочки", 3000, 1500, 5, "20:00–21:30", "Астана"),
    ("Пекарня «Тандыр»", "Самса, 6 шт.", "Самса с мясом и тыквой", 2400, 1200, 4, "19:30–21:00", "Астана"),
    ("Суши-бар «Токио»", "Сет роллов", "24 ролла: филадельфия, калифорния", 7500, 3700, 3, "21:00–22:00", "Астана"),
    ("Кафе «Дастархан»", "Обед дня", "Плов, салат и компот", 2800, 1400, 6, "20:30–22:00", "Алматы"),
    ("Пиццерия «Рим»", "Пицца Маргарита", "Целая пицца 30 см", 4200, 2100, 2, "21:00–22:30", "Алматы"),
    ("Кофейня «Зерно»", "Десерты дня", "Чизкейк и тирамису", 3200, 1600, 4, "20:00–21:00", "Алматы"),
]


def seed_demo():
    for cafe, title, desc, old, new, qty, time_, city in DEMO_OFFERS:
        oid = max(OFFERS, default=0) + 1
        OFFERS[oid] = {"id": oid, "cafe_name": cafe, "title": title, "description": desc,
                       "old_price": old, "new_price": new, "quantity": qty,
                       "pickup_time": time_, "city": city}


def _report_bot_exit(t: asyncio.Task):
    if not t.cancelled() and t.exception():
        logging.getLogger("bot").error("БОТ ОСТАНОВИЛСЯ С ОШИБКОЙ: %r", t.exception())


@asynccontextmanager
async def lifespan(app: FastAPI):
    if os.getenv("SEED_DEMO", "1") == "1" and not OFFERS:
        seed_demo()  # тестовая еда; отключить: SEED_DEMO=0 в .env
    logging.basicConfig(level=logging.INFO, force=True,
                        format="%(asctime)s %(levelname)s %(name)s: %(message)s")
    logging.getLogger("httpx").setLevel(logging.WARNING)
    task = asyncio.create_task(run_bot(standalone=False))  # бот стартует вместе с сайтом
    task.add_done_callback(_report_bot_exit)
    yield
    task.cancel()
    with suppress(asyncio.CancelledError):
        await task


app = FastAPI(title="Остатки еды (тестовый API)", lifespan=lifespan)


@app.get("/")
def root():
    return {"status": "ok", "docs": "/docs"}


@app.get("/api/offers")
def list_offers(city: str | None = None, q: str | None = None):
    items = list(OFFERS.values())
    if city:
        items = [o for o in items if o["city"].lower() == city.lower()]
    if q:
        ql = q.lower()
        items = [o for o in items if ql in (o["title"] + o["description"] + o["cafe_name"]).lower()]
    return items


@app.post("/api/offers", status_code=201)
def create_offer(o: OfferIn):
    if o.new_price >= o.old_price:
        raise HTTPException(422, "new_price must be less than old_price")
    oid = max(OFFERS, default=0) + 1
    OFFERS[oid] = {"id": oid, **o.model_dump()}
    return OFFERS[oid]


@app.post("/api/orders", status_code=201)
def create_order(o: OrderIn):
    offer = OFFERS.get(o.offer_id)
    if not offer:
        raise HTTPException(404, "offer not found")
    if o.quantity > offer["quantity"]:
        raise HTTPException(409, "not enough items left")
    offer["quantity"] -= o.quantity
    total = round(offer["new_price"] * o.quantity, 2)
    order = {"id": len(ORDERS) + 1, "offer_id": o.offer_id, "quantity": o.quantity,
             "customer_name": o.customer_name, "phone": o.phone,
             "telegram_user_id": o.telegram_user_id, "total": total,
             "commission": round(total * COMMISSION, 2)}
    ORDERS.append(order)
    return order


@app.get("/api/orders")
def list_orders(offer_id: int | None = Query(None)):
    return [x for x in ORDERS if offer_id is None or x["offer_id"] == offer_id]


@app.get("/api/stats")
def stats():
    revenue = sum(x["total"] for x in ORDERS)
    return {"offers": len(OFFERS), "orders": len(ORDERS), "revenue": round(revenue, 2),
            "commission": round(revenue * COMMISSION, 2)}
