import html
import re

from bot.api_client import Offer


def esc(s) -> str:
    return html.escape(str(s or ""))


def fmt_money(v: float) -> str:
    return f"{int(round(v)):,}".replace(",", " ") + " ₸"


def parse_price(text: str) -> float | None:
    t = text.strip().replace(" ", "").replace(",", ".").replace("₸", "")
    if not re.fullmatch(r"\d+(\.\d{1,2})?", t):
        return None
    v = float(t)
    return v if 0 < v <= 10_000_000 else None


def parse_int(text: str, max_value: int | None = None) -> int | None:
    t = text.strip()
    if not t.isdigit():
        return None
    v = int(t)
    if v <= 0 or v > 100_000:
        return None
    if max_value is not None and v > max_value:
        return None
    return v


def normalize_phone(text: str) -> str | None:
    """Казахстан/РФ: +7XXXXXXXXXX. Принимает 8..., 7..., +7..., 10 цифр."""
    if not re.fullmatch(r"[\d\s()+\-]{10,18}", text.strip()):
        return None
    digits = re.sub(r"\D", "", text)
    if len(digits) == 10:
        digits = "7" + digits
    if len(digits) == 11 and digits[0] in "78":
        return "+7" + digits[1:]
    return None


def offer_text(o: Offer) -> str:
    parts = [f"🍱 <b>{esc(o.title)}</b>", f"🏪 {esc(o.cafe)}" + (f" · {esc(o.city)}" if o.city else "")]
    if o.description:
        parts.append(esc(o.description))
    parts.append(f"💰 <s>{fmt_money(o.old_price)}</s> → <b>{fmt_money(o.new_price)}</b>")
    parts.append(f"📦 Осталось: {o.quantity}")
    if o.pickup_time:
        parts.append(f"🕒 Забрать: {esc(o.pickup_time)}")
    return "\n".join(parts)
