import os
import re
from dataclasses import dataclass

from dotenv import load_dotenv

load_dotenv(override=True)  # значения из .env важнее переменных Windows

CITIES = ["Астана", "Алматы"]


@dataclass(frozen=True)
class Config:
    bot_token: str
    api_base_url: str
    cafe_access_code: str
    cafe_notify_chat_id: int | None
    db_path: str
    poll_interval: int
    web_app_url: str
    ad_interval_minutes: int


def _env(name: str, default: str = "") -> str:
    """Читает переменную и убирает пробелы и случайные кавычки."""
    return os.getenv(name, default).strip().strip('"').strip("'").strip()


def _int_env(name: str, default: int) -> int:
    """Берёт первое число из значения: '1', '1мин', ' 1 min ' -> 1."""
    m = re.search(r"\d+", _env(name))
    return int(m.group()) if m else default


def _site_url() -> str:
    url = _env("WEB_APP_URL")
    if url and not url.startswith(("http://", "https://")):
        url = "https://" + url
    return url


def load_config() -> Config:
    notify = _env("CAFE_NOTIFY_CHAT_ID")
    return Config(
        bot_token=_env("BOT_TOKEN"),
        api_base_url=_env("API_BASE_URL", "http://127.0.0.1:8000"),
        cafe_access_code=_env("CAFE_ACCESS_CODE"),
        cafe_notify_chat_id=int(notify) if notify.lstrip("-").isdigit() else None,
        db_path=os.getenv("DB_PATH", "bot.sqlite3"),
        poll_interval=_int_env("POLL_INTERVAL", 60),
        web_app_url=_site_url(),
        ad_interval_minutes=_int_env("AD_INTERVAL_MINUTES", 30),
    )
