import asyncio
import logging

from aiogram import Bot
from aiogram.exceptions import TelegramForbiddenError

from bot.api_client import ApiClient, ApiError, ApiUnavailable
from bot.config import CITIES
from bot.storage import Database
from bot.utils import offer_text

log = logging.getLogger(__name__)


async def poll_new_offers(bot: Bot, api: ApiClient, db: Database, interval: int):
    """Опрашивает API и шлёт подписчикам новые предложения (в том числе созданные на сайте)."""
    first = db.seen_count() == 0  # первый запуск: только запоминаем, не рассылаем
    while True:
        try:
            for city in CITIES:
                for o in await api.get_offers(city=city):
                    if db.is_seen(o.id):
                        continue
                    db.mark_seen(o.id)
                    if first or o.quantity <= 0 or (o.city and o.city != city):
                        continue
                    for uid in db.subscribers(city):
                        try:
                            await bot.send_message(uid, "🆕 Новое предложение!\n\n" + offer_text(o),
                                                   parse_mode="HTML")
                        except TelegramForbiddenError:
                            db.drop_user_subs(uid)
                        except Exception:
                            log.warning("Не удалось отправить оповещение")
                        await asyncio.sleep(0.05)
            first = False
        except (ApiUnavailable, ApiError):
            log.info("Опрос предложений: API недоступен, повторю позже")
        except asyncio.CancelledError:
            raise
        except Exception:
            log.exception("Ошибка опроса предложений")
        await asyncio.sleep(interval)
