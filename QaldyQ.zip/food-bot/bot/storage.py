import sqlite3
import threading
import time


class Database:
    def __init__(self, path: str):
        self._db = sqlite3.connect(path, check_same_thread=False)
        self._lock = threading.Lock()
        with self._lock, self._db:
            self._db.executescript("""
            CREATE TABLE IF NOT EXISTS cafes(user_id INTEGER PRIMARY KEY, chat_id INTEGER, name TEXT);
            CREATE TABLE IF NOT EXISTS offer_owners(offer_id TEXT PRIMARY KEY, chat_id INTEGER);
            CREATE TABLE IF NOT EXISTS user_orders(
                id INTEGER PRIMARY KEY AUTOINCREMENT, user_id INTEGER, order_id TEXT,
                title TEXT, qty INTEGER, total REAL, created_at INTEGER);
            CREATE TABLE IF NOT EXISTS subscriptions(
                user_id INTEGER, city TEXT, PRIMARY KEY(user_id, city));
            CREATE TABLE IF NOT EXISTS seen_offers(offer_id TEXT PRIMARY KEY);
            CREATE TABLE IF NOT EXISTS users(user_id INTEGER PRIMARY KEY, ads_on INTEGER DEFAULT 1);
            CREATE TABLE IF NOT EXISTS kv(key TEXT PRIMARY KEY, value TEXT);
            """)

    def backfill_users(self):
        """Добавляет в рассылку тех, кого бот уже знает по заказам, подпискам и кафе."""
        for table in ("user_orders", "subscriptions", "cafes"):
            self._exec(f"INSERT OR IGNORE INTO users(user_id) SELECT DISTINCT user_id FROM {table}")

    def _exec(self, sql, args=()):
        with self._lock, self._db:
            return self._db.execute(sql, args).fetchall()

    # кафе
    def get_cafe(self, user_id: int):
        r = self._exec("SELECT chat_id, name FROM cafes WHERE user_id=?", (user_id,))
        return {"chat_id": r[0][0], "name": r[0][1]} if r else None

    def save_cafe(self, user_id: int, chat_id: int):
        self._exec("INSERT INTO cafes(user_id, chat_id) VALUES(?,?) "
                   "ON CONFLICT(user_id) DO UPDATE SET chat_id=excluded.chat_id", (user_id, chat_id))

    def set_cafe_name(self, user_id: int, name: str):
        self._exec("UPDATE cafes SET name=? WHERE user_id=?", (name, user_id))

    def set_offer_owner(self, offer_id, chat_id: int):
        self._exec("INSERT OR REPLACE INTO offer_owners VALUES(?,?)", (str(offer_id), chat_id))

    def get_offer_owner(self, offer_id) -> int | None:
        r = self._exec("SELECT chat_id FROM offer_owners WHERE offer_id=?", (str(offer_id),))
        return r[0][0] if r else None

    # заказы пользователя
    def add_order(self, user_id: int, order_id, title: str, qty: int, total: float):
        self._exec("INSERT INTO user_orders(user_id, order_id, title, qty, total, created_at) "
                   "VALUES(?,?,?,?,?,?)", (user_id, str(order_id), title, qty, total, int(time.time())))

    def list_orders(self, user_id: int, limit: int = 10):
        return self._exec("SELECT order_id, title, qty, total, created_at FROM user_orders "
                          "WHERE user_id=? ORDER BY id DESC LIMIT ?", (user_id, limit))

    # подписки
    def toggle_sub(self, user_id: int, city: str) -> bool:
        """True, если подписались; False, если отписались."""
        if self._exec("SELECT 1 FROM subscriptions WHERE user_id=? AND city=?", (user_id, city)):
            self._exec("DELETE FROM subscriptions WHERE user_id=? AND city=?", (user_id, city))
            return False
        self._exec("INSERT INTO subscriptions VALUES(?,?)", (user_id, city))
        return True

    def user_subs(self, user_id: int) -> list[str]:
        return [r[0] for r in self._exec("SELECT city FROM subscriptions WHERE user_id=?", (user_id,))]

    def subscribers(self, city: str) -> list[int]:
        return [r[0] for r in self._exec("SELECT user_id FROM subscriptions WHERE city=?", (city,))]

    def drop_user_subs(self, user_id: int):
        self._exec("DELETE FROM subscriptions WHERE user_id=?", (user_id,))

    # уже виденные предложения
    def seen_count(self) -> int:
        return self._exec("SELECT COUNT(*) FROM seen_offers")[0][0]

    def is_seen(self, offer_id) -> bool:
        return bool(self._exec("SELECT 1 FROM seen_offers WHERE offer_id=?", (str(offer_id),)))

    def mark_seen(self, offer_id):
        self._exec("INSERT OR IGNORE INTO seen_offers VALUES(?)", (str(offer_id),))

    # пользователи и реклама
    def add_user(self, user_id: int):
        self._exec("INSERT OR IGNORE INTO users(user_id) VALUES(?)", (user_id,))

    def remove_user(self, user_id: int):
        self._exec("DELETE FROM users WHERE user_id=?", (user_id,))

    def set_ads(self, user_id: int, on: bool):
        self._exec("INSERT INTO users(user_id, ads_on) VALUES(?,?) "
                   "ON CONFLICT(user_id) DO UPDATE SET ads_on=excluded.ads_on", (user_id, int(on)))

    def ad_users(self) -> list[int]:
        return [r[0] for r in self._exec("SELECT user_id FROM users WHERE ads_on=1")]

    def get_kv(self, key: str) -> str | None:
        r = self._exec("SELECT value FROM kv WHERE key=?", (key,))
        return r[0][0] if r else None

    def set_kv(self, key: str, value: str):
        self._exec("INSERT OR REPLACE INTO kv VALUES(?,?)", (key, value))
