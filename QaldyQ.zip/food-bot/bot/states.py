from aiogram.fsm.state import State, StatesGroup


class Buy(StatesGroup):
    name = State()
    phone = State()
    quantity = State()
    confirm = State()


class CafeAuth(StatesGroup):
    code = State()


class NewOffer(StatesGroup):
    cafe_name = State()
    title = State()
    description = State()
    old_price = State()
    new_price = State()
    quantity = State()
    pickup_time = State()
    city = State()
    confirm = State()
