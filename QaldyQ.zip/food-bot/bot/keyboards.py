from aiogram.utils.keyboard import InlineKeyboardBuilder

from aiogram.types import InlineKeyboardButton, InlineKeyboardMarkup, WebAppInfo

from bot.config import CITIES

SITE_URL = ""


def set_site_url(url: str) -> None:
    global SITE_URL
    SITE_URL = url


def site_button() -> InlineKeyboardButton | None:
    """https -> открывается внутри Telegram (Web App); http -> обычная ссылка.
    localhost/127.0.0.1 Telegram не принимает, кнопку не показываем."""
    if not SITE_URL or any(h in SITE_URL for h in ("localhost", "127.0.0.1", "0.0.0.0")):
        return None
    if SITE_URL.startswith("https://"):
        return InlineKeyboardButton(text="🌐 Открыть сайт", web_app=WebAppInfo(url=SITE_URL))
    return InlineKeyboardButton(text="🌐 Открыть сайт", url=SITE_URL)


def main_menu():
    b = InlineKeyboardBuilder()
    b.button(text="🍽 Найти еду", callback_data="find")
    b.button(text="📋 Мои заказы", callback_data="myorders")
    b.adjust(2)
    markup = b.as_markup()
    site = site_button()
    if site:
        markup.inline_keyboard.append([site])
    return markup


def cities(prefix: str):
    b = InlineKeyboardBuilder()
    for c in CITIES:
        b.button(text=c, callback_data=f"{prefix}:{c}")
    b.adjust(2)
    return b.as_markup()


def order_button(offer_id):
    b = InlineKeyboardBuilder()
    b.button(text="🛒 Заказать", callback_data=f"order:{offer_id}")
    return b.as_markup()


def confirm(yes_data: str):
    b = InlineKeyboardBuilder()
    b.button(text="✅ Подтвердить", callback_data=yes_data)
    b.button(text="❌ Отмена", callback_data="cancel")
    b.adjust(2)
    return b.as_markup()


def cafe_menu():
    b = InlineKeyboardBuilder()
    b.button(text="➕ Добавить предложение", callback_data="cafe:add")
    return b.as_markup()
