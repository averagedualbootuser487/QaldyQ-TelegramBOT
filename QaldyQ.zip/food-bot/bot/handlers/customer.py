import logging
from dataclasses import asdict

from aiogram import Bot, F, Router
from aiogram.filters import Command, CommandStart
from aiogram.fsm.context import FSMContext
from aiogram.types import CallbackQuery, Message

from bot import keyboards as kb
from bot.api_client import ApiClient, ApiError, ApiUnavailable
from bot.config import Config
from bot.states import Buy
from bot.storage import Database
from bot.utils import esc, fmt_money, normalize_phone, offer_text, parse_int

log = logging.getLogger(__name__)
router = Router()
TEXT = F.text & ~F.text.startswith("/")  # команды не должны попадать в шаги FSM

WELCOME = ("👋 Здесь кафе продают непроданную еду в конце дня со скидкой. "
           "Меньше выброшенной еды, дешевле для вас.")
HELP = ("Что умею:\n/start — главное меню\n/find — найти еду\n/orders — мои заказы\n"
        "/site — открыть сайт\n/subscribe — оповещения о новых предложениях\n"
        "/cafe — раздел для кафе\n"
        "/cancel — отменить текущее действие")
DOWN = "⚠️ Сервер сейчас недоступен. Попробуйте через пару минут."
ERR = "⚠️ Не удалось выполнить запрос. Попробуйте позже."


@router.message(CommandStart())
async def start(m: Message, state: FSMContext):
    await state.clear()
    await m.answer(WELCOME, reply_markup=kb.main_menu())


@router.message(Command("help"))
async def help_(m: Message):
    await m.answer(HELP)


@router.message(Command("site"))
async def site_cmd(m: Message):
    btn = kb.site_button()
    if not btn:
        await m.answer("Ссылка на сайт не настроена (WEB_APP_URL).")
        return
    await m.answer("Наш сайт:", reply_markup=kb.InlineKeyboardMarkup(inline_keyboard=[[btn]]))


@router.message(Command("cancel"))
async def cancel_cmd(m: Message, state: FSMContext):
    await state.clear()
    await m.answer("Отменено.", reply_markup=kb.main_menu())


@router.callback_query(F.data == "cancel")
async def cancel_cb(cb: CallbackQuery, state: FSMContext):
    await cb.answer()
    await state.clear()
    await cb.message.answer("Отменено.", reply_markup=kb.main_menu())


# ---------- поиск ----------
@router.message(Command("find"))
async def find_cmd(m: Message, state: FSMContext):
    await state.clear()
    await m.answer("Выберите город:", reply_markup=kb.cities("city"))


@router.callback_query(F.data == "find")
async def find_cb(cb: CallbackQuery, state: FSMContext):
    await cb.answer()
    await state.clear()
    await cb.message.answer("Выберите город:", reply_markup=kb.cities("city"))


async def send_offers(msg: Message, api: ApiClient, city: str | None):
    try:
        offers = [o for o in await api.get_offers(city=city) if o.quantity > 0]
    except ApiUnavailable:
        await msg.answer(DOWN)
        return
    except ApiError:
        await msg.answer(ERR)
        return
    if not offers:
        await msg.answer(f"Пока нет доступных предложений{' в городе ' + city if city else ''}. "
                         "Загляните позже или оформите /subscribe.")
        return
    for o in offers[:10]:
        await msg.answer(offer_text(o), parse_mode="HTML", reply_markup=kb.order_button(o.id))
    if len(offers) > 10:
        await msg.answer(f"Показаны 10 из {len(offers)} предложений.")


@router.callback_query(F.data.startswith("city:"))
async def city_chosen(cb: CallbackQuery, api: ApiClient):
    await cb.answer()
    await send_offers(cb.message, api, cb.data.split(":", 1)[1])


# ---------- заказ ----------
@router.callback_query(F.data.startswith("order:"))
async def order_start(cb: CallbackQuery, state: FSMContext, api: ApiClient):
    await cb.answer()
    offer_id = cb.data.split(":", 1)[1]
    try:
        offer = await api.find_offer(offer_id)
    except ApiUnavailable:
        await cb.message.answer(DOWN)
        return
    except ApiError:
        await cb.message.answer(ERR)
        return
    if offer is None or offer.quantity <= 0:
        await cb.message.answer("😔 Этот набор уже закончился. Вот другие предложения:")
        await send_offers(cb.message, api, offer.city if offer else None)
        return
    await state.clear()
    await state.update_data(offer=asdict(offer))
    await state.set_state(Buy.name)
    await cb.message.answer(f"Оформляем: <b>{esc(offer.title)}</b>.\nКак вас зовут? (/cancel — отмена)",
                            parse_mode="HTML")


@router.message(Buy.name, TEXT)
async def buy_name(m: Message, state: FSMContext):
    name = m.text.strip()
    if not 2 <= len(name) <= 50:
        await m.answer("Имя должно быть от 2 до 50 символов. Попробуйте ещё раз.")
        return
    await state.update_data(name=name)
    await state.set_state(Buy.phone)
    await m.answer("Ваш телефон? Например, +7 701 123 45 67")


async def ask_confirm(m: Message, state: FSMContext):
    d = await state.get_data()
    o = d["offer"]
    total = o["new_price"] * d["qty"]
    await state.set_state(Buy.confirm)
    await m.answer(
        "Проверьте заказ:\n"
        f"🍱 {esc(o['title'])} ({esc(o['cafe'])})\n"
        f"🔢 Количество: {d['qty']}\n"
        f"💰 К оплате при получении: <b>{fmt_money(total)}</b>\n"
        f"🕒 Забрать: {esc(o['pickup_time'])}\n"
        f"👤 {esc(d['name'])}, {esc(d['phone'])}",
        parse_mode="HTML", reply_markup=kb.confirm("confirm_order"))


@router.message(Buy.phone, TEXT)
async def buy_phone(m: Message, state: FSMContext):
    phone = normalize_phone(m.text)
    if not phone:
        await m.answer("Не похоже на номер. Формат: +7 701 123 45 67")
        return
    await state.update_data(phone=phone)
    left = (await state.get_data())["offer"]["quantity"]
    if left > 1:
        await state.set_state(Buy.quantity)
        await m.answer(f"Сколько штук? Доступно: {left}")
    else:
        await state.update_data(qty=1)
        await ask_confirm(m, state)


@router.message(Buy.quantity, TEXT)
async def buy_qty(m: Message, state: FSMContext):
    left = (await state.get_data())["offer"]["quantity"]
    qty = parse_int(m.text, max_value=left)
    if qty is None:
        await m.answer(f"Введите целое число от 1 до {left}.")
        return
    await state.update_data(qty=qty)
    await ask_confirm(m, state)


@router.callback_query(Buy.confirm, F.data == "confirm_order")
async def buy_confirm(cb: CallbackQuery, state: FSMContext, api: ApiClient,
                      db: Database, cfg: Config, bot: Bot):
    await cb.answer()
    d = await state.get_data()
    o, qty = d["offer"], d["qty"]
    try:
        order = await api.create_order(offer_id=o["id"], quantity=qty, name=d["name"],
                                       phone=d["phone"], telegram_user_id=cb.from_user.id)
    except ApiUnavailable:
        await cb.message.answer(DOWN + " Нажмите «Подтвердить» ещё раз чуть позже.",
                                reply_markup=kb.confirm("confirm_order"))
        return
    except ApiError:
        # возможно, товар разобрали: перепроверим остаток
        try:
            fresh = await api.find_offer(str(o["id"]))
        except (ApiUnavailable, ApiError):
            fresh = None
        await state.clear()
        if fresh is None or fresh.quantity < qty:
            await cb.message.answer("😔 Не хватило остатка, набор уже разобрали. Другие предложения:")
            await send_offers(cb.message, api, o["city"] or None)
        else:
            await cb.message.answer(ERR)
        return

    order_id = order.get("id") or order.get("order_id") or "—"
    total = o["new_price"] * qty
    db.add_order(cb.from_user.id, order_id, o["title"], qty, total)
    await state.clear()
    await cb.message.answer(
        f"✅ Заказ №{esc(order_id)} оформлен!\nЗабрать: {esc(o['pickup_time'])}, {esc(o['cafe'])}.\n"
        f"Оплата при получении: {fmt_money(total)}.", parse_mode="HTML", reply_markup=kb.main_menu())

    chat = db.get_offer_owner(o["id"]) or cfg.cafe_notify_chat_id
    if chat:
        try:
            await bot.send_message(
                chat,
                f"🔔 Новый заказ №{esc(order_id)}\n{esc(o['title'])} × {qty}\n"
                f"Клиент: {esc(d['name'])}, {esc(d['phone'])}", parse_mode="HTML")
        except Exception:
            log.warning("Не удалось уведомить кафе (offer_id=%s)", o["id"])


# ---------- мои заказы ----------
async def show_orders(msg: Message, user_id: int, db: Database):
    rows = db.list_orders(user_id)
    if not rows:
        await msg.answer("У вас пока нет заказов.", reply_markup=kb.main_menu())
        return
    lines = [f"№{esc(r[0])} — {esc(r[1])} × {r[2]}, {fmt_money(r[3])}" for r in rows]
    await msg.answer("📋 Ваши последние заказы:\n" + "\n".join(lines), parse_mode="HTML")


@router.message(Command("orders"))
async def orders_cmd(m: Message, db: Database):
    await show_orders(m, m.from_user.id, db)


@router.callback_query(F.data == "myorders")
async def orders_cb(cb: CallbackQuery, db: Database):
    await cb.answer()
    await show_orders(cb.message, cb.from_user.id, db)


# ---------- подписка ----------
@router.message(Command("subscribe"))
async def subscribe_cmd(m: Message, db: Database):
    subs = db.user_subs(m.from_user.id)
    cur = ", ".join(subs) if subs else "нет"
    await m.answer(f"Ваши подписки: {cur}.\nНажмите на город, чтобы подписаться или отписаться:",
                   reply_markup=kb.cities("sub"))


@router.callback_query(F.data.startswith("sub:"))
async def subscribe_toggle(cb: CallbackQuery, db: Database):
    city = cb.data.split(":", 1)[1]
    on = db.toggle_sub(cb.from_user.id, city)
    await cb.answer("Подписка оформлена" if on else "Подписка отключена")
    await cb.message.answer(f"{'🔔 Подписались на' if on else '🔕 Отписались от'} оповещений: {city}.")
