import hmac
import logging

from aiogram import F, Router
from aiogram.filters import Command
from aiogram.fsm.context import FSMContext
from aiogram.types import CallbackQuery, Message

from bot import keyboards as kb
from bot.api_client import ApiClient, ApiError, ApiUnavailable
from bot.config import Config
from bot.states import CafeAuth, NewOffer
from bot.storage import Database
from bot.utils import esc, fmt_money, parse_int, parse_price

log = logging.getLogger(__name__)
router = Router()
TEXT = F.text & ~F.text.startswith("/")


@router.message(Command("cafe"))
async def cafe_cmd(m: Message, state: FSMContext, db: Database, cfg: Config):
    await state.clear()
    if not cfg.cafe_access_code:
        await m.answer("Раздел для кафе не настроен (нет CAFE_ACCESS_CODE).")
        return
    if db.get_cafe(m.from_user.id):
        await m.answer("Вы вошли как кафе.", reply_markup=kb.cafe_menu())
        return
    await state.set_state(CafeAuth.code)
    await state.update_data(tries=0)
    await m.answer("Введите код доступа для кафе (/cancel — отмена):")


@router.message(CafeAuth.code, TEXT)
async def cafe_code(m: Message, state: FSMContext, db: Database, cfg: Config):
    try:
        await m.delete()  # код не должен висеть в чате
    except Exception:
        pass
    ok = hmac.compare_digest(m.text.strip().encode(), cfg.cafe_access_code.encode())
    if ok:
        db.save_cafe(m.from_user.id, m.chat.id)
        await state.clear()
        await m.answer("✅ Доступ открыт.", reply_markup=kb.cafe_menu())
        return
    tries = (await state.get_data()).get("tries", 0) + 1
    if tries >= 5:
        await state.clear()
        await m.answer("Слишком много попыток. Начните заново через /cafe.")
        return
    await state.update_data(tries=tries)
    await m.answer("Неверный код. Попробуйте ещё раз.")


# ---------- добавление предложения ----------
async def begin_add(msg: Message, state: FSMContext, db: Database, user_id: int):
    cafe = db.get_cafe(user_id)
    if not cafe:
        await msg.answer("Сначала войдите: /cafe")
        return
    await state.clear()
    if cafe["name"]:
        await state.update_data(cafe_name=cafe["name"])
        await state.set_state(NewOffer.title)
        await msg.answer("Название набора? (/cancel — отмена)")
    else:
        await state.set_state(NewOffer.cafe_name)
        await msg.answer("Название вашего кафе? (/cancel — отмена)")


@router.message(Command("addoffer"))
async def add_cmd(m: Message, state: FSMContext, db: Database):
    await begin_add(m, state, db, m.from_user.id)


@router.callback_query(F.data == "cafe:add")
async def add_cb(cb: CallbackQuery, state: FSMContext, db: Database):
    await cb.answer()
    await begin_add(cb.message, state, db, cb.from_user.id)


@router.message(NewOffer.cafe_name, TEXT)
async def o_cafe(m: Message, state: FSMContext, db: Database):
    name = m.text.strip()
    if not 2 <= len(name) <= 60:
        await m.answer("От 2 до 60 символов, пожалуйста.")
        return
    db.set_cafe_name(m.from_user.id, name)
    await state.update_data(cafe_name=name)
    await state.set_state(NewOffer.title)
    await m.answer("Название набора?")


@router.message(NewOffer.title, TEXT)
async def o_title(m: Message, state: FSMContext):
    t = m.text.strip()
    if not 2 <= len(t) <= 80:
        await m.answer("Название: от 2 до 80 символов.")
        return
    await state.update_data(title=t)
    await state.set_state(NewOffer.description)
    await m.answer("Что в наборе? (короткое описание)")


@router.message(NewOffer.description, TEXT)
async def o_desc(m: Message, state: FSMContext):
    t = m.text.strip()
    if len(t) > 300:
        await m.answer("Слишком длинно, до 300 символов.")
        return
    await state.update_data(description=t)
    await state.set_state(NewOffer.old_price)
    await m.answer("Старая цена в ₸ (только число):")


@router.message(NewOffer.old_price, TEXT)
async def o_old(m: Message, state: FSMContext):
    p = parse_price(m.text)
    if p is None:
        await m.answer("Нужно число больше нуля, например 2500.")
        return
    await state.update_data(old_price=p)
    await state.set_state(NewOffer.new_price)
    await m.answer("Цена со скидкой в ₸:")


@router.message(NewOffer.new_price, TEXT)
async def o_new(m: Message, state: FSMContext):
    p = parse_price(m.text)
    old = (await state.get_data())["old_price"]
    if p is None or p >= old:
        await m.answer(f"Нужно число больше нуля и меньше старой цены ({fmt_money(old)}).")
        return
    await state.update_data(new_price=p)
    await state.set_state(NewOffer.quantity)
    await m.answer("Сколько штук в наличии?")


@router.message(NewOffer.quantity, TEXT)
async def o_qty(m: Message, state: FSMContext):
    q = parse_int(m.text)
    if q is None:
        await m.answer("Нужно целое число больше нуля.")
        return
    await state.update_data(quantity=q)
    await state.set_state(NewOffer.pickup_time)
    await m.answer("Время забора, например 20:00–21:30:")


@router.message(NewOffer.pickup_time, TEXT)
async def o_time(m: Message, state: FSMContext):
    t = m.text.strip()
    if not 3 <= len(t) <= 40:
        await m.answer("Напишите время, например 20:00–21:30.")
        return
    await state.update_data(pickup_time=t)
    await state.set_state(NewOffer.city)
    await m.answer("Город:", reply_markup=kb.cities("ocity"))


@router.callback_query(NewOffer.city, F.data.startswith("ocity:"))
async def o_city(cb: CallbackQuery, state: FSMContext):
    await cb.answer()
    await state.update_data(city=cb.data.split(":", 1)[1])
    d = await state.get_data()
    await state.set_state(NewOffer.confirm)
    await cb.message.answer(
        "Проверьте предложение:\n"
        f"🏪 {esc(d['cafe_name'])} · {esc(d['city'])}\n🍱 <b>{esc(d['title'])}</b>\n{esc(d['description'])}\n"
        f"💰 <s>{fmt_money(d['old_price'])}</s> → <b>{fmt_money(d['new_price'])}</b>\n"
        f"📦 {d['quantity']} шт. · 🕒 {esc(d['pickup_time'])}",
        parse_mode="HTML", reply_markup=kb.confirm("offer_ok"))


@router.callback_query(NewOffer.confirm, F.data == "offer_ok")
async def o_confirm(cb: CallbackQuery, state: FSMContext, api: ApiClient, db: Database):
    await cb.answer()
    d = await state.get_data()
    payload = {k: d[k] for k in ("cafe_name", "title", "description", "old_price",
                                 "new_price", "quantity", "pickup_time", "city")}
    try:
        res = await api.create_offer(payload)
    except ApiUnavailable:
        await cb.message.answer("⚠️ Сервер недоступен. Нажмите «Подтвердить» ещё раз чуть позже.",
                                reply_markup=kb.confirm("offer_ok"))
        return
    except ApiError as e:
        await state.clear()
        log.warning("create_offer отклонён: HTTP %s", e.status)
        await cb.message.answer("⚠️ Сервер не принял предложение. Проверьте данные и повторите.",
                                reply_markup=kb.cafe_menu())
        return
    offer_id = res.get("id")
    if offer_id is not None:
        cafe = db.get_cafe(cb.from_user.id)
        db.set_offer_owner(offer_id, cafe["chat_id"])
    await state.clear()
    await cb.message.answer("✅ Предложение опубликовано. Подписчики получат оповещение.",
                            reply_markup=kb.cafe_menu())
