import logging
from dataclasses import dataclass

import httpx

log = logging.getLogger(__name__)


class ApiUnavailable(Exception):
    """Сервер недоступен или отвечает 5xx."""


class ApiError(Exception):
    def __init__(self, status: int, detail: str = ""):
        super().__init__(f"HTTP {status}")
        self.status = status
        self.detail = detail


@dataclass
class Offer:
    id: int | str
    cafe: str
    title: str
    description: str
    old_price: float
    new_price: float
    quantity: int
    pickup_time: str
    city: str

    @classmethod
    def from_api(cls, d: dict) -> "Offer":
        # Единственное место, где нужно подогнать имена полей под ваш API.
        def num(*keys, default=0):
            for k in keys:
                if d.get(k) is not None:
                    try:
                        return float(d[k])
                    except (TypeError, ValueError):
                        pass
            return default

        return cls(
            id=d.get("id"),
            cafe=str(d.get("cafe_name") or d.get("cafe") or "Кафе"),
            title=str(d.get("title") or d.get("name") or "Набор"),
            description=str(d.get("description") or ""),
            old_price=num("old_price", "original_price"),
            new_price=num("new_price", "discount_price", "price"),
            quantity=int(num("quantity_left", "remaining", "quantity")),
            pickup_time=str(d.get("pickup_time") or d.get("pickup") or ""),
            city=str(d.get("city") or ""),
        )


class ApiClient:
    def __init__(self, base_url: str):
        self._c = httpx.AsyncClient(
            base_url=base_url.rstrip("/"), timeout=httpx.Timeout(10.0, connect=5.0)
        )

    async def close(self):
        await self._c.aclose()

    async def _req(self, method: str, path: str, **kw):
        try:
            r = await self._c.request(method, path, **kw)
        except httpx.HTTPError as e:
            raise ApiUnavailable(type(e).__name__) from e
        if r.status_code >= 500:
            raise ApiUnavailable(f"HTTP {r.status_code}")
        if r.status_code >= 400:
            # тело ответа не логируем: там могут быть персональные данные
            raise ApiError(r.status_code, r.text[:200])
        try:
            return r.json()
        except ValueError as e:
            raise ApiUnavailable("bad json") from e

    async def get_offers(self, city: str | None = None, q: str | None = None) -> list[Offer]:
        params = {k: v for k, v in {"city": city, "q": q}.items() if v}
        data = await self._req("GET", "/api/offers", params=params)
        if isinstance(data, dict):
            data = data.get("items") or data.get("offers") or []
        return [Offer.from_api(x) for x in data if isinstance(x, dict)]

    async def find_offer(self, offer_id: str) -> Offer | None:
        for o in await self.get_offers():
            if str(o.id) == str(offer_id):
                return o
        return None

    async def create_offer(self, o: dict) -> dict:
        return await self._req("POST", "/api/offers", json=o)

    async def create_order(self, *, offer_id, quantity: int, name: str, phone: str,
                           telegram_user_id: int) -> dict:
        return await self._req("POST", "/api/orders", json={
            "offer_id": offer_id,
            "quantity": quantity,
            "customer_name": name,
            "phone": phone,
            "telegram_user_id": telegram_user_id,
        })

    async def stats(self) -> dict:
        return await self._req("GET", "/api/stats")
