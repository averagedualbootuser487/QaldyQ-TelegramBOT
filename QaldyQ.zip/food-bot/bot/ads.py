"""Реклама: каждые 30 минут (AD_INTERVAL_MINUTES) бот рассылает следующую рекламу по кругу.
Тексты редактируйте в списке ADS ниже. Отправляется обычным текстом (без HTML)."""
import asyncio
import logging
import time

from aiogram import Bot
from aiogram.exceptions import TelegramForbiddenError

from bot.storage import Database

log = logging.getLogger(__name__)

ADS = [
    """🌱 AUAHACK — ECO-BUSINESS HACKATHON

Ready to turn your ideas into solutions that can make a real impact? 👀

AuaHack is an eco-business hackathon organized in collaboration with AuaSense and Riviera International School.

You don’t need advanced coding skills to participate — all you need is creativity, fresh ideas, and a passion for solving real-world problems.

💡 All tracks, case studies, challenges, and judging criteria will be revealed on the day of the hackathon.

🎟️ Participation is completely FREE!
👥 Team size: 2–4 members from 9-12 grades.
📢 End of the deadline : October 21, 2026
📌 In-person round: October 24, 2026

Ready to show the world what your ideas can do?

See you at AuaHack! 🚀""",

    """📌 IMPORTANT RULES & INFORMATION

Please read the following information carefully before tomorrow’s AuaHack Hackathon!

1. Cases, Regulations & Tracks
All cases, the official regulations, and hackathon tracks will be announced tomorrow at the event.

2. Extension Cords
Teams are recommended to bring their own extension cords if needed.

3. Team & Room Allocation
Teams will be assigned to designated classrooms. Each classroom will accommodate 2 teams, and 1 volunteer will be assigned to every 2 teams to provide assistance throughout the hackathon.

💙 Please make sure to read all the information carefully and follow the instructions provided by the organizers.

See you tomorrow! 🚀""",

    """IMPORTANT! 👀

Kindly reminder that our hackathon will be in English, and you should be able to present your presentation in 1 minute 30 seconds!""",
]


async def ads_loop(bot: Bot, db: Database, interval_minutes: int):
    interval = max(1, interval_minutes) * 60
    db.backfill_users()
    log.info("Реклама: интервал %s мин, получателей сейчас: %s", interval_minutes, len(db.ad_users()))
    if not db.get_kv("last_ad_ts"):
        db.set_kv("last_ad_ts", str(int(time.time())))  # первая реклама через полный интервал
    while True:
        try:
            last = int(db.get_kv("last_ad_ts") or 0)
            wait = last + interval - int(time.time())
            if wait > 0:
                await asyncio.sleep(min(wait, 60))  # просыпаемся раз в минуту
                continue

            idx = int(db.get_kv("ad_index") or 0) % len(ADS)
            text = ADS[idx]
            db.set_kv("ad_index", str(idx + 1))
            db.set_kv("last_ad_ts", str(int(time.time())))

            recipients = db.ad_users()
            if not recipients:
                log.warning("Реклама: нет получателей. Напишите боту /start в Telegram.")
            sent = 0
            for uid in recipients:
                try:
                    await bot.send_message(uid, text)  # без parse_mode: спецсимволы безопасны
                    sent += 1
                except TelegramForbiddenError:
                    db.remove_user(uid)  # заблокировал бота; вернётся в список, когда снова напишет
                except Exception:
                    log.warning("Не удалось отправить рекламу одному из пользователей")
                await asyncio.sleep(0.05)  # лимиты Telegram
            log.info("Реклама №%s отправлена %s пользователям", idx + 1, sent)
        except asyncio.CancelledError:
            raise
        except Exception:
            log.exception("Ошибка рассылки рекламы")
            await asyncio.sleep(30)
