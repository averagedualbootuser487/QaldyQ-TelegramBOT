import asyncio
import logging
from contextlib import suppress

from aiogram import BaseMiddleware, Bot, Dispatcher
from aiogram.exceptions import TelegramUnauthorizedError
from aiogram.types import MenuButtonWebApp, WebAppInfo
from aiogram.fsm.storage.memory import MemoryStorage

from bot import keyboards as kb
from bot.ads import ads_loop
from bot.api_client import ApiClient
from bot.config import load_config
from bot.handlers import cafe, customer
from bot.notifier import poll_new_offers
from bot.storage import Database

log = logging.getLogger(__name__)


class TrackUsers(BaseMiddleware):
    """Запоминает всех, кто писал боту: им уходит реклама."""

    def __init__(self, db: Database):
        self.db = db

    async def __call__(self, handler, event, data):
        user = data.get("event_from_user")
        if user and not user.is_bot:
            self.db.add_user(user.id)
        return await handler(event, data)


async def run_bot(standalone: bool = True) -> None:
    cfg = load_config()
    if not cfg.bot_token:
        msg = "BOT_TOKEN не задан: бот не запущен."
        if standalone:
            raise SystemExit(msg)
        log.error(msg)  # внутри сайта не роняем веб-сервер
        return

    kb.set_site_url(cfg.web_app_url)
    bot = Bot(cfg.bot_token)
    api = ApiClient(cfg.api_base_url)
    db = Database(cfg.db_path)

    dp = Dispatcher(storage=MemoryStorage())
    dp.include_router(customer.router)  # первым: /start, /cancel работают в любом состоянии
    dp.include_router(cafe.router)
    dp.update.outer_middleware(TrackUsers(db))
    dp.workflow_data.update(api=api, db=db, cfg=cfg)

    poller = asyncio.create_task(poll_new_offers(bot, api, db, cfg.poll_interval))
    ads = asyncio.create_task(ads_loop(bot, db, cfg.ad_interval_minutes))
    try:
        try:
            me = await bot.get_me()
        except TelegramUnauthorizedError:
            msg = (f"Telegram не принял токен (длина {len(cfg.bot_token)}, начало "
                   f"'{cfg.bot_token[:6]}'). Скопируйте его заново у @BotFather: "
                   "/mybots -> ваш бот -> API Token.")
            if standalone:
                raise SystemExit(msg)
            log.error(msg)
            return
        log.info("Бот @%s запущен. Реклама каждые %s мин.", me.username, cfg.ad_interval_minutes)
        if cfg.web_app_url.startswith("https://") and kb.site_button():
            await bot.set_chat_menu_button(menu_button=MenuButtonWebApp(
                text="Сайт", web_app=WebAppInfo(url=cfg.web_app_url)))
        await bot.delete_webhook(drop_pending_updates=True)
        await dp.start_polling(bot, handle_signals=standalone)
    finally:
        for t in (poller, ads):
            t.cancel()
            with suppress(asyncio.CancelledError):
                await t
        await api.close()
        await bot.session.close()


def main():
    logging.basicConfig(level=logging.INFO,
                        format="%(asctime)s %(levelname)s %(name)s: %(message)s")
    logging.getLogger("httpx").setLevel(logging.WARNING)  # не светим URL с параметрами
    with suppress(KeyboardInterrupt):
        asyncio.run(run_bot(standalone=True))


if __name__ == "__main__":
    main()
