# Telegram-бот для маркетплейса остатков еды

## Структура
Папку `bot/` и файлы `.env.example`, `.gitignore` положите в корень вашего проекта (рядом с папкой сайта/API).
Строки из `requirements.txt` добавьте к вашему requirements.txt.

## Запуск локально
    pip install -r requirements.txt
    cp .env.example .env      # впишите BOT_TOKEN и CAFE_ACCESS_CODE
    python -m bot.main        # запускать из корня проекта

## Вместе с сайтом (один процесс)
См. lifespan_example.py. На деплое: API_BASE_URL=http://127.0.0.1:$PORT

## Токен
@BotFather -> /newbot -> скопировать токен в .env (BOT_TOKEN). Токен не коммитить.

## Проверка цепочки
1. curl $API_BASE_URL/api/stats  (запомнить числа)
2. /cafe -> код -> добавить предложение
3. Со второго аккаунта оформить заказ
4. curl $API_BASE_URL/api/stats  (заказы и выручка выросли)

## Если API использует другие имена полей
Правьте Offer.from_api и create_order / create_offer в bot/api_client.py и payload в bot/handlers/cafe.py.

## Кнопка «Открыть сайт» (WEB_APP_URL)
Впишите ссылку в .env: WEB_APP_URL=https://ваш-сайт.com
- https: кнопка открывает сайт внутри Telegram (Web App) + кнопка «Сайт» в меню слева от поля ввода.
- http: обычная ссылка. localhost/127.0.0.1 Telegram не принимает: нужна публичная ссылка.
- Команда /site тоже показывает кнопку. Кнопка работает без FastAPI-сервера.

## Тестовый API (если своего API ещё нет)
В папке app/ лежит готовый тестовый сервер с /api/offers, /api/orders, /api/stats.
    pip install -r requirements.txt
    python -m uvicorn app.main:app
Одна команда запускает и сайт/API (http://127.0.0.1:8000/docs), и бота.
Отдельно `python -m bot.main` при этом НЕ запускайте (два бота с одним токеном конфликтуют).
Данные тестового API хранятся в памяти и пропадают при перезапуске.

## Реклама
Каждые AD_INTERVAL_MINUTES (по умолчанию 30) бот рассылает всем, кто ему писал, следующую рекламу из списка ADS в bot/ads.py (по кругу).
Тексты правятся там же. Для проверки поставьте AD_INTERVAL_MINUTES=1.
